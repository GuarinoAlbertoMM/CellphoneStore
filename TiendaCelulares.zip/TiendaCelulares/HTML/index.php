<?php
session_start(); // Inicia la sesión para poder verificar el estado del usuario
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Productos - Tienda de Celulares</title>
  <style>
    /* General Styles */
    body {
      font-family: 'Arial', sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f4f4;
    }
    header {
      background-color: #333;
      color: white;
      padding: 10px 0;
      text-align: center;
    }
    .header-title {
      font-size: 2rem;
    }
    nav {
      display: flex;
      justify-content: center;
      background-color: #444;
      padding: 10px;
    }
    nav a {
      color: white;
      text-decoration: none;
      padding: 10px;
      margin: 0 15px;
      transition: background-color 0.3s;
    }
    nav a:hover {
      background-color: #575757;
    }
    .product-section {
      padding: 20px;
    }
    .section-title {
      font-size: 1.5rem;
      color: #333;
      text-align: center;
    }
    /* Controles para productos */
    .product-controls {
      text-align: center;
      margin-bottom: 20px;
    }
    .product-controls button {
      padding: 10px 15px;
      margin: 0 10px;
      border: none;
      border-radius: 5px;
      background-color: #333;
      color: white;
      cursor: pointer;
      transition: background-color 0.3s;
    }
    .product-controls button:hover {
      background-color: #575757;
    }
    .product-container {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: 20px;
      padding: 20px;
    }
    .product-card {
      background-color: white;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      position: relative;
    }
    .product-card img {
      width: 100%;
      height: auto;
    }
    .product-info {
      padding: 15px;
      text-align: center;
    }
    .product-name {
      font-size: 1.2rem;
      color: #333;
    }
    .product-description {
      color: #777;
    }
    .product-price {
      color: #28a745;
      font-weight: bold;
      font-size: 1.5rem;
    }
    .remove-product-btn {
      margin-top: 10px;
      padding: 5px 10px;
      background-color: #c0392b;
      color: white;
      border: none;
      border-radius: 3px;
      cursor: pointer;
      transition: background-color 0.3s;
    }
    .remove-product-btn:hover {
      background-color: #e74c3c;
    }
    footer {
      background-color: #333;
      color: white;
      text-align: center;
      padding: 20px 0;
      margin-top: 30px;
    }
    .footer-text {
      margin: 0;
    }
    /* Estilos para el modal del formulario */
    #addProductModal {
      display: none; /* oculto por defecto */
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0,0,0,0.5);
      justify-content: center;
      align-items: center;
    }
    #addProductModal .modal-content {
      background: white;
      padding: 20px;
      border-radius: 10px;
      max-width: 500px;
      width: 90%;
    }
    #addProductModal input,
    #addProductModal textarea {
      width: 100%;
      padding: 10px;
      margin: 5px 0;
      box-sizing: border-box;
    }
    #addProductModal button {
      margin-top: 10px;
      padding: 10px 15px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <header>
    <h1 class="header-title">Bienvenido a la Tienda de Celulares</h1>
  </header>

  <nav>
    <a href="index.php" class="nav-link">Inicio</a>
    <a href="catalog.html" class="nav-link">Productos</a>
    <a href="contact-seller.html" class="nav-link">Contacto</a>
    <a href="register.html" class="nav-link">Registro</a>
    <?php if (isset($_SESSION['user_id'])): ?>
      <a href="../PHP/profile.php" class="nav-link">Perfil</a>
    <?php else: ?>
      <a href="login.html" class="nav-link">Iniciar Sesión</a>
    <?php endif; ?>
  </nav>

  <section id="productos" class="product-section">
    <h2 class="section-title">Nuestros Productos</h2>
    <!-- Mostrar controles solo para usuarios autenticados -->
    <?php if (isset($_SESSION['user_id'])): ?>
      <div class="product-controls">
        <button id="openModal">Agregar Producto</button>
      </div>
    <?php endif; ?>
    <div class="product-container">
      <!-- Producto 1 -->
      <div class="product-card">
        <img src="..\img\galaxys24.jpg" alt="Producto" class="product-image">
        <div class="product-info">
          <h3 class="product-name">Samsung Galaxy S24</h3>
          <p class="product-description">Descripción del producto.</p>
          <p class="product-price">$39,999.99</p>
          <?php if(isset($_SESSION['user_id'])): ?>
            <button class="remove-product-btn">Remover</button>
          <?php endif; ?>
        </div>
      </div>
      <!-- Producto 2 -->
      <div class="product-card">
        <img src="..\img\galaxys24-ultra.jpg" alt="Producto" class="product-image">
        <div class="product-info">
          <h3 class="product-name">Samsung Galaxy S24 Ultra</h3>
          <p class="product-description">Descripción del producto.</p>
          <p class="product-price">$59,999.99</p>
          <?php if(isset($_SESSION['user_id'])): ?>
            <button class="remove-product-btn">Remover</button>
          <?php endif; ?>
        </div>
      </div>
      <!-- Producto 3 -->
      <div class="product-card">
        <img src="..\img\iphone15.jpg" alt="Producto" class="product-image">
        <div class="product-info">
          <h3 class="product-name">IPhone 15</h3>
          <p class="product-description">Descripción del producto.</p>
          <p class="product-price">$49,999.99</p>
          <?php if(isset($_SESSION['user_id'])): ?>
            <button class="remove-product-btn">Remover</button>
          <?php endif; ?>
        </div>
      </div>
      <!-- Producto 4 -->
      <div class="product-card">
        <img src="..\img\iphone15-promax.jpg" alt="Producto" class="product-image">
        <div class="product-info">
          <h3 class="product-name">IPhone 15 Pro Max</h3>
          <p class="product-description">Descripción del producto.</p>
          <p class="product-price">$69,999.99</p>
          <?php if(isset($_SESSION['user_id'])): ?>
            <button class="remove-product-btn">Remover</button>
          <?php endif; ?>
        </div>
      </div>
      <!-- Producto 5 -->
      <div class="product-card">
        <img src="..\img\pixel7pro.jpg" alt="Producto" class="product-image">
        <div class="product-info">
          <h3 class="product-name">Pixel 7 Pro</h3>
          <p class="product-description">Descripción del producto.</p>
          <p class="product-price">$59,999.99</p>
          <?php if(isset($_SESSION['user_id'])): ?>
            <button class="remove-product-btn">Remover</button>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </section>

  <!-- Modal para agregar un nuevo producto -->
  <div id="addProductModal">
    <div class="modal-content">
      <h3>Agregar Nuevo Producto</h3>
      <form id="addProductForm">
        <input type="text" name="productName" placeholder="Nombre del producto" required>
        <textarea name="productDescription" placeholder="Descripción del producto" required></textarea>
        <input type="number" step="0.01" name="productPrice" placeholder="Precio del producto" required>
        <input type="file" name="productImage" accept="image/*" required>
        <button type="submit">Agregar Producto</button>
        <button type="button" id="closeModal">Cancelar</button>
      </form>
    </div>
  </div>

  <footer>
    <p class="footer-text">© 2025 Tienda de Celulares</p>
  </footer>

 
  <script src="..\js\scripts.js"></script>
</body>
</html>